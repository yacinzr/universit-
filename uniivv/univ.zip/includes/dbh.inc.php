<?php

$dbserverName = "localhost";
$dbuserName = "root";
$dbpassword = "";
$dbname = "loginsystem";

$conn = mysqli_connect( $dbserverName , $dbuserName , $dbpassword , $dbname );